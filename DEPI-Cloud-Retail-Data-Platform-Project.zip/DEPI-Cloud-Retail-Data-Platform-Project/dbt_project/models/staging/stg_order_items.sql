{{ config(materialized='view') }}

with source as (
    select *
    from {{ source('ods', 'order_items') }}
)

select
    order_item_id,
    cast(created_at as timestamp) as created_at,
    order_id,
    product_id,
    cast(is_primary_item as boolean) as is_primary_item,
    cast(price_usd as decimal(12, 2)) as price_usd,
    cast(cogs_usd as decimal(12, 2)) as cogs_usd
from source
