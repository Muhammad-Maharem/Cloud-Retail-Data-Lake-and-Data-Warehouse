{{ config(materialized='view') }}

with source as (
    select *
    from {{ source('ods', 'website_pageviews') }}
)

select
    website_pageview_id,
    cast(created_at as timestamp) as created_at,
    website_session_id,
    pageview_url
from source
