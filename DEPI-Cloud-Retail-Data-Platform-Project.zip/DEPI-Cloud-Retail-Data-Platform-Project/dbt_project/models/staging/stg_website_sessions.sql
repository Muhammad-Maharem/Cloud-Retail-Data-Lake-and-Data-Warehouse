{{ config(materialized='view') }}

with source as (
    select *
    from {{ source('ods', 'website_sessions') }}
)

select
    website_session_id,
    cast(created_at as timestamp) as created_at,
    user_id,
    cast(is_repeat_session as boolean) as is_repeat_session,
    utm_source,
    utm_campaign,
    utm_content,
    device_type,
    http_referer
from source
