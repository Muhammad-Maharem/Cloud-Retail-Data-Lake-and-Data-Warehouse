{{ config(materialized='view') }}

with source as (
    select *
    from {{ source('ods', 'order_item_refunds') }}
)

select
    order_item_refund_id,
    cast(created_at as timestamp) as created_at,
    order_id,
    order_item_id,
    cast(refund_amount_usd as decimal(12, 2)) as refund_amount_usd
from source
