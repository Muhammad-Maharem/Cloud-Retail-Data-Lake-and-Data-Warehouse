{{ config(materialized='view') }}

with source as (
    select *
    from {{ source('ods', 'products') }}
)

select
    product_id,
    cast(created_at as timestamp) as created_at,
    product_name
from source
