{{ config(materialized='view') }}

with source as (
    select *
    from {{ source('ods', 'orders') }}
)

select
    order_id,
    cast(created_at as timestamp) as created_at,
    website_session_id,
    user_id,
    primary_product_id,
    cast(items_purchased as integer) as items_purchased,
    cast(price_usd as decimal(12, 2)) as price_usd,
    cast(cogs_usd as decimal(12, 2)) as cogs_usd
from source
