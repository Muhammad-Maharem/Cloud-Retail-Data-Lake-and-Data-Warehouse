{{ config(materialized='table') }}

with sessions as (

    select *
    from {{ ref('stg_website_sessions') }}

),

devices as (

    select distinct
        coalesce(
            nullif(trim(device_type), ''),
            'Unknown'
        ) as device_type
    from sessions

)

select
    row_number() over (
        order by device_type
    ) as device_key,

    device_type

from devices
