{{ config(materialized='table') }}

with order_dates as (

    select cast(created_at as date) as date_day
    from {{ ref('stg_order_items') }}
    where created_at is not null

),

unique_dates as (

    select distinct date_day
    from order_dates

)

select
    cast(strftime(date_day, '%Y%m%d') as integer) as date_key,
    date_day,
    extract(year from date_day)::integer as year,
    extract(quarter from date_day)::integer as quarter,
    extract(month from date_day)::integer as month,
    strftime(date_day, '%B') as month_name,
    extract(day from date_day)::integer as day_of_month,
    extract(dow from date_day)::integer as day_of_week,
    strftime(date_day, '%A') as day_name,

    case
        when extract(dow from date_day) in (0, 6)
        then true
        else false
    end as is_weekend

from unique_dates
