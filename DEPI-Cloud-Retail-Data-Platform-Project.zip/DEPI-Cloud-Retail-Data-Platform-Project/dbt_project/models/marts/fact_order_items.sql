
{{ config(materialized='table') }}

with order_items as (

    select *
    from {{ ref('stg_order_items') }}

),

orders as (

    select *
    from {{ ref('stg_orders') }}

),

sessions as (

    select *
    from {{ ref('stg_website_sessions') }}

),

refunds as (

    select
        order_item_id,
        sum(refund_amount_usd) as refund_amount_usd
    from {{ ref('stg_order_item_refunds') }}
    group by order_item_id

),

order_item_details as (

    select

        -- Order Item Attributes
        oi.order_item_id,
        oi.order_id,
        oi.product_id,
        oi.created_at as order_item_created_at,
        oi.is_primary_item,
        oi.price_usd,
        oi.cogs_usd,

        -- Order Attributes
        o.website_session_id,
        o.user_id,
        o.created_at as order_created_at,

        -- Session Attributes
        s.device_type,
        s.utm_source,
        s.utm_campaign,
        s.utm_content,
        s.http_referer,

        -- Refund Measure
        coalesce(r.refund_amount_usd, 0)
            as refund_amount_usd

    from order_items oi

    left join orders o
        on oi.order_id = o.order_id

    left join sessions s
        on o.website_session_id = s.website_session_id

    left join refunds r
        on oi.order_item_id = r.order_item_id

)

select

    -- Dimension Keys
    dd.date_key as order_date_key,

    dt.time_key as order_time_key,

    dp.product_key,

    dv.device_key,

    tr.traffic_key,

    -- Degenerate Dimensions / Identifiers
    details.order_item_id,
    details.order_id,
    details.website_session_id,
    details.user_id,

    -- Order Item Attributes
    details.is_primary_item,

    -- Measures
    1 as items_qty,

    details.price_usd,

    details.cogs_usd,

    details.price_usd - details.cogs_usd
        as gross_margin_usd,

    details.refund_amount_usd,

    details.price_usd - details.refund_amount_usd
        as net_revenue_usd,

    -- Profit After Refunds
    details.price_usd
        - details.refund_amount_usd
        - details.cogs_usd
        as net_profit_after_refunds_usd

from order_item_details details

-- Date Dimension
left join {{ ref('dim_date') }} dd
    on cast(details.order_item_created_at as date)
       = dd.date_day

-- Time Dimension
left join {{ ref('dim_time') }} dt
    on dt.time_key = (
        extract(hour from details.order_created_at) * 100
        + extract(minute from details.order_created_at)
    )

-- Product Dimension
left join {{ ref('dim_product') }} dp
    on details.product_id = dp.product_key

-- Device Dimension
left join {{ ref('dim_device') }} dv
    on coalesce(
        nullif(trim(details.device_type), ''),
        'Unknown'
    ) = dv.device_type

-- Traffic Dimension
left join {{ ref('dim_traffic') }} tr
    on coalesce(
        nullif(trim(details.utm_source), ''),
        'Unknown'
    ) = tr.utm_source

    and coalesce(
        nullif(trim(details.utm_campaign), ''),
        'Unknown'
    ) = tr.utm_campaign

    and coalesce(
        nullif(trim(details.utm_content), ''),
        'Unknown'
    ) = tr.utm_content

    and coalesce(
        nullif(trim(details.http_referer), ''),
        'Unknown'
    ) = tr.http_referer
