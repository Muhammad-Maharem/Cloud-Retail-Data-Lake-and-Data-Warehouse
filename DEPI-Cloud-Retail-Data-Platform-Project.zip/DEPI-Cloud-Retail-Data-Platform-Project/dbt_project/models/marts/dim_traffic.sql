{{ config(materialized='table') }}

with sessions as (

    select *
    from {{ ref('stg_website_sessions') }}

),

traffic_sources as (

    select distinct

        coalesce(
            nullif(trim(utm_source), ''),
            'Unknown'
        ) as utm_source,

        coalesce(
            nullif(trim(utm_campaign), ''),
            'Unknown'
        ) as utm_campaign,

        coalesce(
            nullif(trim(utm_content), ''),
            'Unknown'
        ) as utm_content,

        coalesce(
            nullif(trim(http_referer), ''),
            'Unknown'
        ) as http_referer

    from sessions

)

select

    row_number() over (
        order by
            utm_source,
            utm_campaign,
            utm_content,
            http_referer
    ) as traffic_key,

    utm_source,
    utm_campaign,
    utm_content,
    http_referer

from traffic_sources
