{{ config(materialized='table') }}

with minutes_of_day as (

    select
        minute_number
    from generate_series(0, 1439) as minutes(minute_number)

),

time_attributes as (

    select
        cast(minute_number as integer) as minute_number,

        cast(minute_number // 60 as integer) as hour_24,

        cast(minute_number % 60 as integer) as minute

    from minutes_of_day

)

select

    -- Primary Key: HHMM
    cast(
        hour_24 * 100 + minute
        as integer
    ) as time_key,

    hour_24,

    minute,

    -- HH:mm format
    lpad(cast(hour_24 as varchar), 2, '0')
        || ':'
        || lpad(cast(minute as varchar), 2, '0')
        as time_label,

    -- Day Part Classification
    case
        when hour_24 between 5 and 11
            then 'Morning'

        when hour_24 between 12 and 16
            then 'Afternoon'

        when hour_24 between 17 and 20
            then 'Evening'

        else 'Night'
    end as day_part

from time_attributes
