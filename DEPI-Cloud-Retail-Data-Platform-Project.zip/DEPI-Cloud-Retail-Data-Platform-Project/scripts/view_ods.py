from pathlib import Path
import duckdb
import pandas as pd

# Database path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DB_PATH = PROJECT_ROOT / "dbt_project" / "dev.duckdb"

# Connect to DuckDB
con = duckdb.connect(str(DB_PATH), read_only=True)

# Get all tables in the ods schema
tables = con.execute("""
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'ods'
""").fetchdf()

# Display each table using Pandas
for table_name in tables["table_name"]:
    print(f"\nTable: ods.{table_name}")

    df = con.execute(
        f'SELECT * FROM ods."{table_name}" LIMIT 10'
    ).fetchdf()

    print(df)

# Close connection
con.close()

