from pathlib import Path
import duckdb

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DB_PATH = PROJECT_ROOT / "dbt_project" / "dev.duckdb"

con = duckdb.connect(str(DB_PATH), read_only=True)

result = con.execute("""
    SELECT COUNT(*)
    FROM main_dwh.dim_time
""").fetchone()[0]

print(f"dim_time row count: {result:,}")

con.close()
