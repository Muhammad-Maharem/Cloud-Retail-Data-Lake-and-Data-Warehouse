from pathlib import Path
import duckdb
import pandas as pd

# Database path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DB_PATH = PROJECT_ROOT / "dbt_project" / "dev.duckdb"

# Connect to DuckDB
con = duckdb.connect(str(DB_PATH), read_only=True)

# Get all tables in the stg schema
tables = con.execute("""
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'main_dwh'
""").fetchall()

# Display the first 5 rows of each table
for (table_name,) in tables:
    print(f"\nTable: main_dwh.{table_name}")

    rows = con.execute(
        f'SELECT * FROM main_dwh."{table_name}" LIMIT 5'
    ).fetchall()

    for row in rows:
        print(row)

con.close()
