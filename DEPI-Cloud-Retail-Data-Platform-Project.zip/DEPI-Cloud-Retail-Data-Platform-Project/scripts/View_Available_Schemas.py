
from pathlib import Path
import duckdb

# ==========================================
# 1. Database Configuration
# ==========================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DB_PATH = PROJECT_ROOT / "dbt_project" / "dev.duckdb"

print(f"Database Path: {DB_PATH}")
print(f"Database Exists: {DB_PATH.exists()}")

if not DB_PATH.exists():
    raise FileNotFoundError(f"Database not found: {DB_PATH}")


# ==========================================
# 2. Connect to DuckDB
# ==========================================

con = duckdb.connect(str(DB_PATH), read_only=True)

try:

    # ==========================================
    # 3. Display Available Schemas
    # ==========================================

    schemas = con.execute("""
        SELECT schema_name
        FROM information_schema.schemata
        ORDER BY schema_name
    """).fetchall()

    print("\nAvailable Schemas:")

    for (schema_name,) in schemas:
        print(f"- {schema_name}")


finally:
    con.close()

print("\nDatabase inspection completed!")
